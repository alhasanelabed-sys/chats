"""ADMS / PUSH server."""
